// symbol-realtime-news.component.ts
import { Component, Input } from '@angular/core';
import { GeneralService } from 'src/app/core/services/general.service';

@Component({
  selector: 'app-symbol-realtime-news',
  templateUrl: './symbol-realtime-news.component.html',
  styleUrls: ['./symbol-realtime-news.component.css']
})
export class SymbolRealtimeNewsComponent {
  @Input() symbol: string;
  newsData: any[] = []; // Ensure newsData is defined as an array
  loading: boolean = true;
  errorMessage: string = '';

  constructor(private generalService: GeneralService) {}

  loadNews(symbol: string) {
    this.loading = true;
    this.generalService.getNews(symbol).subscribe(
      (data) => {
        console.log('News data:', data); // Check if data is being received
        this.newsData = data.articles || []; // Adjust according to API response format
        this.loading = false;
      },
      (error) => {
        console.error('Error fetching news:', error);
        this.loading = false;
      }
    );
  }
}
